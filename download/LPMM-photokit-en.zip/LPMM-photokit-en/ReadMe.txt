The LPMM photokit is a set of Automator scripts, Automator actions and color management profiles. Its purpose is photo processing, especially processing of raw files. It provides a convenient mean to quickly process batches of photos, using at best the finest details stored in the raw files.

Currently supported cameras are :
- Fujifilm FinePix E900
- Nikon D60
- Panasonic DMC-FZ18

This set can be easily installed with MacOS 10.4 or higher.

These tools should easily be adapted for use in other technological contexts:
- other computer systems than Macintosh;
- other camera models;
- other printing system than Fujifilm Frontier 570.

Under MacOS X, double click the "install.command" icon. This will open a Terminal window requesting your confirmation.

You will also have to install some open source tools :
- dcraw <http://cybercom.net/~dcoffin/dcraw/> <http://www.insflug.org/raw/>
- ImageMagick (with support of the LCMS colorimetric library) <http://www.imagemagick.org/>
- exiftool <http://www.sno.phy.queensu.ca/~phil/exiftool/>
Other non free softwares are unnecessary for normal use :
- Adobe DNG Converter
- sips, included in MacOS X.

After installation, the tools are accessed in the Finder through the Automator contextual menu. You can process individual files or a batch of selected files.

RAW files will be moved to a "raws" subfolder (if they aren't already in there).
The full resolution PNG files will be placed in a "hires" subfolder.

Your opinions and suggestions are welcomed at photokit@barijaona.com .

Donations are welcomed through Paypal at <https://sourceforge.net/donate/index.php?user_id=1343767>.

The script in the "source" folder are Copyright (c) 2007, Barijaona Ramaholimihaso <photokit@barijaona.com>

All rights reserved.
Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
	�	Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
	�	Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
	�	Neither the name of Barijaona Ramaholimihaso nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The "CA_Frontier570_Generic.icc" color profile is copyrighted by FUJIFILM UK Limited <http://www.fujifilm.co.uk/colour/generic_profiles/>.

The "ProPhoto.icm" colore profile is copyrighted by Eastman Kodak Company.

# Blosxom Plugin: seeerror					   -*- perl -*-
# Author: Todd Larason (jtl@molehill.org)
# Hacked by Barijaona Ramaholimihaso for experimental blosxom4
# Version: 2007-08-18blosxom4 (based on 0+1i)
# Blosxom Home/Docs/Licensing: http://www.raelity.org/blosxom
# Categories plugin Home/Docs/Licensing:
#   http://molelog.molehill.org/blomt/archives/computers/internet/web/blosxom/plugins/seeerror/

package Blosxom::Plugin::seeerror;

# ------------------------- Configuration Variables --------------------------
# Directory to create the temporary files in.
# Criteria:
# *  It MUST exist
# *  It MUST be writable
# *  It SHOULD be readable outside Blosxom
$tmp_dir ||= "/tmp";

# Attempt to deal with fatal errors?  Should only be enabled if you need it.
$handle_die = 0
  unless defined $handle_die;
# ----------------------------------------------------------------------------

use FileHandle;
use CGI;

my $tmp_file = sprintf "$tmp_dir/bloserr-$$-$^T-%s.txt", CGI::remote_host();
open STDERR,"> $tmp_file";

if ($handle_die) {
    $SIG{__DIE__} = sub {
	print "content-type: text/html\n\n<h2>Fatal error</h2>$@";
	}
}

sub start {1;}
sub end {
    close STDERR;  # force a flush
    my $fh = new FileHandle;
    $fh->open("< $tmp_file");
    my $errors = join '',<$fh>;
    $fh->close;
    if ($errors) {
	$errors =~ s:&:&amp;:g;
	$errors =~ s:<:&lt;:g;
	print "<h2>Errors and warnings</h2><pre>$errors</pre>";
    }
    unlink($tmp_file);
    return 1;
}
1;

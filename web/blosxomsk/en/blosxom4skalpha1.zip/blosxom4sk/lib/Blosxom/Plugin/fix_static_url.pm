# Blosxom plugin: fix-static-url
# Author(s): Barijaona Ramaholimihaso
# Version: 2007-08-18blosxom4
# Documentation: see bottom of file or perldoc title

package Blosxom::Plugin::fix_static_url;
# ------------------ Configuration variables ---------------

use vars qw($static_url);

# Define the url
# define it in your settings or
# use the prefs plugin
$static_url = "" unless defined $static_url;

# ---------------------------------------------------------


sub start {
	if ( $blosxom::static_or_dynamic eq 'static') {
		$blosxom::url= $static_url;
		return 1;
	 }
	 else {return 0 };
}

1;
__END__
=head1 NAME

Blosxom Plug-in: fix_static_url

=head1 SYNOPSIS

This plugin corrects the $blosxom::url variable for static rendering.

When you use blosxom for rendering static pages, the $url variable refers to your local machine, which is rarely acurate, especially if you intend to upload the static files to a different server... You have to explicitly assign the $url variable in the source of blosxom, or you can use this plugin as an alternative.

You can assign the $Blosxom::Plugin::fix_static_url::static_url variable in the settings file, or use the prefs plugin to define
$fix_static_url::static_url.

=head1 VERSION

2007-08-18blosxom4

=head2 CHANGES

2007-08-18blosxom4 : ported to blosxom4 (much simpler than previous version)

2004-08-22blosxom2 : First published version

=head1 AUTHOR

Barijaona Ramaholimihaso <http://homepage.mac.com/barijaona>

=head1 SEE ALSO

Blosxom Home/Docs/Licensing: http://blosxom.sourceforge.net

Blosxom Plugin Docs: http://blosxom.sourceforge.net/plugins/

=head1 BUGS

Address bug reports and comments to the Blosxom mailing list 
[http://sourceforge.net/mailarchive/forum.php?forum_name=blosxom-users].

=head1 COPYRIGHT

This program is free software; you can redistribute
it and/or modify it under the same terms as Perl itself.

=cut
